I have just revised this extension so that it works with the latest Google Chrome interface
You can now
* Click anywhere on a page & get a shortened URL for the current page
* Click on a link & get a shortened URL for the link
* Click on an image & get a shortened URL for the image
* As above but for video files
* As above but for audio files

This extension is now in version 3. I did not even realise that my version 2 extension was not working until I saw 2
separate 1 star reviews saying that the extension did not work. It turned out that Google had dropped support for the
notification type I was using.

I have spent tonight updating the extension and it is once again ready to go live.

@todo Add an icon and a badge. When popup is requested it can give a history of shortened urls
@todo Analytics so people can see how popular their shortened URLs have been

Changelog
---------
3.0.1 Updated Manifest file

3.0.0 Updated notifications away from WebKitNotifications

2.0.0 Added HTML file with ability to copy and test in new tab

1.0.0 Initial version