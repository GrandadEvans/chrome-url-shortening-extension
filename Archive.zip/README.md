I have just revised this extension so that it works with the latest Google Chrome interface
You can now
* Click anywhere on a page & get a shortened URL for the current page
* Click on a link & get a shortened URL for the link
* Click on an image & get a shortened URL for the image
* As above but for video files
* As above but for audio files

This extension is now in version 3. I did not even realise that my version 2 extension was not working until I saw 2
separate 1 star reviews saying that the extension did not work. It turned out that Google had dropped support for the
notification type I was using.

I have spent tonight updating the extension and it is once again ready to go live.
